# Law 2 Template

This folder is reserved for the next law implementation.
